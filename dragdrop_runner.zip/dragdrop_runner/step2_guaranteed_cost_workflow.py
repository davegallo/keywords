#!/usr/bin/env python3
# (Short header) See previous message for full docstring.
import argparse, datetime, os
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment

DEFAULT_FILL = "FFFF00"
DEFAULT_FONT = "FF0000"
DEFAULT_TEXT = "No Guaranteed Cost"
STATUS_HEADER = "GuaranteedCostStatus"
CENTER = Alignment(horizontal="center", vertical="center")

def is_empty(value):
    if value is None: return True
    if isinstance(value, str) and value.strip() == "": return True
    return False

def apply_flag(cell, text, fill_hex, font_hex, bold=True):
    cell.value = text
    cell.fill = PatternFill(fill_type="solid", start_color=fill_hex, end_color=fill_hex)
    cell.font = Font(color=font_hex, bold=bold)
    cell.alignment = CENTER

def clear_prior_flags_p_r(ws, start_row, end_row, text_to_clear):
    COL_P, COL_R = 16, 18
    for row in range(start_row, end_row + 1):
        for col in (COL_P, COL_R):
            cell = ws.cell(row=row, column=col)
            if cell.value == text_to_clear:
                cell.value = None
            cell.fill = PatternFill()
            cell.font = Font()

def ensure_status_column(ws):
    header_row = 1
    max_col = ws.max_column or 1
    for col in range(1, max_col + 1):
        if (ws.cell(row=header_row, column=col).value or "") == STATUS_HEADER:
            return col
    status_col = max_col + 1
    ws.cell(row=header_row, column=status_col).value = STATUS_HEADER
    ws.cell(row=header_row, column=status_col).alignment = CENTER
    return status_col

def process_sheet(ws, *, start_row=2, end_row=None, clear_prior=True, write_status=True,
                  flag_text=DEFAULT_TEXT, fill_color=DEFAULT_FILL, font_color=DEFAULT_FONT, bold=True):
    COL_P, COL_Q, COL_R, COL_S = 16, 17, 18, 19
    max_row = ws.max_row or 1
    end_row = end_row or max_row
    if end_row < start_row:
        return {"rows_checked": 0, "p_flagged": 0, "r_flagged": 0, "both_flagged": 0}

    if clear_prior:
        clear_prior_flags_p_r(ws, start_row, end_row, text_to_clear=flag_text)

    status_col = ensure_status_column(ws) if write_status else None

    rows_checked = 0
    p_flagged_total = 0
    r_flagged_total = 0
    both_flagged = 0

    for row in range(start_row, end_row + 1):
        rows_checked += 1
        q_val = ws.cell(row=row, column=COL_Q).value
        s_val = ws.cell(row=row, column=COL_S).value

        flagged_p = False
        flagged_r = False

        if is_empty(q_val):
            apply_flag(ws.cell(row=row, column=COL_P), flag_text, fill_color, font_color, bold=bold)
            flagged_p = True
        if is_empty(s_val):
            apply_flag(ws.cell(row=row, column=COL_R), flag_text, fill_color, font_color, bold=bold)
            flagged_r = True

        if flagged_p: p_flagged_total += 1
        if flagged_r: r_flagged_total += 1
        if flagged_p and flagged_r: both_flagged += 1

        if write_status:
            if flagged_p and flagged_r:
                status = "Missing Q & S → P + R flagged"
            elif flagged_p:
                status = "Missing Q → P flagged"
            elif flagged_r:
                status = "Missing S → R flagged"
            else:
                status = "OK"
            ws.cell(row=row, column=status_col).value = status
            ws.cell(row=row, column=status_col).alignment = Alignment(horizontal="center", vertical="center")

    return {
        "rows_checked": rows_checked,
        "p_flagged": p_flagged_total,
        "r_flagged": r_flagged_total,
        "both_flagged": both_flagged,
    }

def main():
    parser = argparse.ArgumentParser(description="Guaranteed Cost workflow with formatting, clearing, and audit options.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--sheet", default=None)
    parser.add_argument("--start-row", type=int, default=2)
    parser.add_argument("--end-row", type=int, default=0)
    parser.add_argument("--no-clear", action="store_true")
    parser.add_argument("--no-status", action="store_true")
    parser.add_argument("--flag-text", default=DEFAULT_TEXT)
    parser.add_argument("--fill-color", default=DEFAULT_FILL)
    parser.add_argument("--font-color", default=DEFAULT_FONT)
    parser.add_argument("--no-bold", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--backup", action="store_true")
    args = parser.parse_args()

    from shutil import copy2
    if args.backup:
        base, ext = os.path.splitext(args.input)
        import datetime
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = f"{base}.backup_{ts}{ext}"
        copy2(args.input, backup_path)
        print(f"[Backup] Created: {backup_path}")

    wb = load_workbook(args.input)
    sheets = [args.sheet] if args.sheet else wb.sheetnames

    totals = {"rows_checked": 0, "p_flagged": 0, "r_flagged": 0, "both_flagged": 0}
    for name in sheets:
        if name not in wb.sheetnames:
            raise SystemExit(f"Sheet '{name}' not found.")
        ws = wb[name]
        end_row = args.end_row if args.end_row and args.end_row > 0 else ws.max_row or 1

        stats = process_sheet(
            ws,
            start_row=args.start_row,
            end_row=end_row,
            clear_prior=(not args.no_clear),
            write_status=(not args.no_status),
            flag_text=args.flag_text,
            fill_color=args.fill_color,
            font_color=args.font_color,
            bold=(not args.no_bold),
        )

        totals["rows_checked"] += stats["rows_checked"]
        totals["p_flagged"] += stats["p_flagged"]
        totals["r_flagged"] += stats["r_flagged"]
        totals["both_flagged"] += stats["both_flagged"]
        print(f"[Sheet: {name}] Rows checked: {stats['rows_checked']}, P flagged: {stats['p_flagged']}, R flagged: {stats['r_flagged']}, Both flagged: {stats['both_flagged']}")

    print(f"[TOTAL] Rows checked: {totals['rows_checked']}, P flagged: {totals['p_flagged']}, R flagged: {totals['r_flagged']}, Both flagged: {totals['both_flagged']}")

    if not args.dry_run:
        wb.save(args.output)
        print(f"[Saved] {args.output}")
    else:
        print("[Dry-run] No file written.")

if __name__ == "__main__":
    main()
