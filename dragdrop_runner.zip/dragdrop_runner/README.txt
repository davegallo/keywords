Drag & Drop Runner — Guaranteed Cost Workflow
============================================
How to use (Windows):
1) Ensure Python is installed (https://www.python.org/downloads/windows/). During install, tick "Add Python to PATH".
2) Download this folder, keep files together:
   - Run_GuaranteedCost_DragDrop.bat
   - step2_guaranteed_cost_workflow.py
3) Drag one or more .xlsx files ONTO the .bat icon.
4) Output files are written next to the originals with suffix: _processed.xlsx

Notes:
- The .bat will auto-install "openpyxl" if it's missing.
- To customize behavior (colors, status column, clearing, etc.), edit the .bat to pass extra flags,
  e.g., add:  --no-clear  --no-status  --flag-text "No GC"  --fill-color FFF2CC  --font-color 9C0006
